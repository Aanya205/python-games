from django.shortcuts import render
from django.http import HttpResponse
#httpresponse is used to get the response from the html pages


def hello(request):
    text = """<h1>welcome to the app</h1>"""
    return HttpResponse(text)
# h1 is a tag which is used to give a heading in HTML. Though we do a seperate HTML coding and later import it in the views.py but here we have directly
#passing the request parameter means we are sending the request to the browser in order to display the message on the screen. It returns HTTP response that means request an HTTP reponse we have to always give
#In HTML language we have tags for each and everything that means if we want to give the image we have img tag, if we want to go from one page we have a tag, if we want to give the text we have h1,h2,h3,h4,h5,h6 tab,similarly we have so many other tags for different things. All we have to do is use the tag due to the requrment. Like in python we have function in HTML tags for everything
# 3 main
