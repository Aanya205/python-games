
# Create your views here.
from django.shortcuts import render
from django.shortcuts import render, redirect 
#Goal of project :
# there will be one home page when we clickc on that it takes us to the form page when 
#details submitted there checks with form valid it takes to success page. This is all redirecting to another page
#when some action happens like success

def home(request):
  return render(request,"home.html" )


def process_form(request):
  if request.method=="POST":
    return redirect("success")
  return render(request, "forms.html")
    


def success(request):
  return render(request,"sucess.html")
  
