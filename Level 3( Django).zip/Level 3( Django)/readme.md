Steps 1:
Use "cd" and copy paste the path of the folder where the project needs to be created

Step 2:
To create a project the command is (django-admin startproject (project name))

Step 3:
Use cd and write down the path of the project that has been created

Step 4:
python manage.py startapp (name)
Add the app name in the settings.py

Step 5:
To run the code you have to :
    python manage.py runserver