from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
def hello(request):
    t = loader.get_template("C:/Users/aanya/OneDrive/Desktop/Python/Level 3( Django)/s75/app5/templates/index.html")
    return HttpResponse(t.render())


# Create your views here.
