from django.contrib import admin
#admin.site.register(Book)
#admin.site.register(Author)

# Register your models here.
#steps to create the admin username
#Step 1 : Use command python manage.py migrate in terminal
#use command python manage.py createsuperuser
#give username passwork and email
#After that run the command for the output
#copy the link of the output and then write /admin to open the admin page ad then use the same
#username and password in order to log into the admin panel
#admin panel is something that controls the basic operations of the website and almost every website has the admin panel in all languages we have to create admin but indjango the admin panel is almost created, this is the benefit of using the django framework


#hw:
#create a bloh\ page l ike the cofee one you can right click on the images on the page itself and copy to insert into your page.