from django.apps import AppConfig


class App8Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app8'
