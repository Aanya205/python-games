from django.db import models
#
#Models are used to work with database it's a way to create tables , insert data and do other things
#Models are used only in django so if we don't use django then we can't use models we will have to use noraml queires
#Models just gives us another way to work with the databse instead of writing queries
#Relationships between different tables are :
# 1) One to one relationship - We have one table connected to another table
# 2) Many to one relationship - Many tables are connected to one table
# 3) One to many relationship - One table is connected to many tables
#Advantages of establishing the relationship between the tables:
#1) It saves time
#2) Discrepency can be avoided - if one table is going to take all the details from the first table then there is a 0 chance that there will be any mis matching of data
#3) If by chance we upgrade or delete data in one table the table connected to it will automatically upgrade
#4) 2 tables can only be connected if they have a common column

#from django.contrib.auth.models import User
#class phone represents database while phone_number and user_id represents the column names
#phone_number represents the table name


#class phone(models.Model):
 #   phone_number = models.CharField(max_length = 10)
  #  user_id = models.OneToOneFiel (User on_delete = models.CASCADE)

   # def _str_(self):
       #return self.phone_number
    # the above is an example of a one to one relationship in this we are connecting inbuilt user tablw with the phone number and because they are connected.
    #If the phone number column in table phone gets deleted then the phone no. column will be delet and if we update yhe column it will get updated in the other table as well.
    # creating a class means that we are creating a table and when we create a charfeild its when we create the different columns in the table

#One to many relationships:
#In this many tables are connected to one another single table 
#We create one table with a class departement

#create class departmenet coloumns will be department id and depratmnet name and the table name is departmenr 1
# user is an inbuiblt table
class department(models.Model):
    department_id = models.CharField(max_length = 10)
    department_name = models.CharFeild(max_length = 10)
    
    def _str_(self):
        return self.department_name
    
class employee(models.Model):
    employee_id = models.CharFeils(max_length = 10)

    user_id = models.ForeignKey(department, on_delete = models.CASCADE)

   # two user defined classes are connected


class teacher(models.Model):
    teacher_id = models.CharFeild(max_length = 10)
    teacher_name = models.CharFeild(max_length = 10)

class student(models.Model):
    student_id = models.CharFeild(max_length = 10)
    teacher_id = models.ForeignKey(department, on_delete = models.CASCADE)



#Working Student Class 
# Create your models here.
#Create one class

#Create 2 classes and connect them for ur assignment
#cafecoffewebsite webpage3
