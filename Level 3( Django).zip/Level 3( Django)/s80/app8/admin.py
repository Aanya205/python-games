from django.contrib import admin
from .models import phone

# Register your models here.
