from django.shortcuts import render
from django.http import loader
from django.http import HttpResponse
# Create your views here.

# steps to give the image in django webpage:
#First create two folders in the app one static and the other templates. In static we will store all the images while in templates we will store all the html and css files
#Secondly in html file load static at the top and use the <img> tag in the body tag. The coding is done in the html file
#Third : Create a function in views.py and load the html file over here
#Fourth : Call the function as usual in url.py
#Fifth : In the settings.py at the end at the static path and the coding for that is already done in the settings.py at the end

def hello(request):
    a = loader.get_template("indx.html")
    return HttpResponse(a.render())
 