from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse

def function(request):
    template = loader.get_template("index.html")
    username = {"name":"Aanya"}
    password = {"password":"Aanya.123"}
    return HttpResponse (template.render(username))
    return HttpResponse (template.render(password))



# Create your views here.
