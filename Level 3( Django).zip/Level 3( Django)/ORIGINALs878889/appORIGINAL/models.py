from django.db import models
from django.utils import timezone

# Create your models here.

class Student(models.Model):
    name = models.CharField(max_length=100)
    roll = models.IntegerField(unique=True)
    email = models.EmailField(blank=True, null=True)
    grade = models.CharField(max_length=2, choices=[
        ('A+', 'A+'), ('A', 'A'), ('B+', 'B+'), ('B', 'B'), 
        ('C+', 'C+'), ('C', 'C'), ('D', 'D'), ('F', 'F')
    ], blank=True, null=True)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['roll']
    
    def __str__(self):
        return f"Student(name={self.name}, roll={self.roll})"
