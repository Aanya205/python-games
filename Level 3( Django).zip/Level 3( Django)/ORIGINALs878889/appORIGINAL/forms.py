from django import forms
from .models import Student

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['name', 'roll', 'email', 'grade']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter student name'
            }),
            'roll': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter roll number'
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter email address'
            }),
            'grade': forms.Select(attrs={
                'class': 'form-control'
            })
        }

class StudentFilterForm(forms.Form):
    search = forms.CharField(
        max_length=100,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Search by name or roll number'
        })
    )
    grade = forms.ChoiceField(
        choices=[('', 'All Grades')] + [
            ('A+', 'A+'), ('A', 'A'), ('B+', 'B+'), ('B', 'B'), 
            ('C+', 'C+'), ('C', 'C'), ('D', 'D'), ('F', 'F')
        ],
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    sort_by = forms.ChoiceField(
        choices=[
            ('roll', 'Roll Number'),
            ('name', 'Name'),
            ('grade', 'Grade'),
            ('created_at', 'Date Added')
        ],
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    order = forms.ChoiceField(
        choices=[('asc', 'Ascending'), ('desc', 'Descending')],
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
