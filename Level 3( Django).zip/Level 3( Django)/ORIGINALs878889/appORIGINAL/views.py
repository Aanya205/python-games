
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.db.models import Q
from .models import Student
from .forms import StudentForm, StudentFilterForm

def student_form(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Student added successfully!')
            return redirect('student_list')
    else:
        form = StudentForm()
    
    return render(request, 'student_form.html', {'form': form})

def student_update(request, pk):
    student = get_object_or_404(Student, pk=pk) # update command
    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            messages.success(request, 'Student updated successfully!')
            return redirect('student_list')
    else:
        form = StudentForm(instance=student)
    
    return render(request, 'student_form.html', {
        'form': form, 
        'student': student,
        'is_update': True
    })

def student_delete(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == 'POST':
        student.delete()
        messages.success(request, 'Student deleted successfully!')
        return redirect('student_list')
    
    return render(request, 'student_confirm_delete.html', {'student': student})

def student_list(request):
    filter_form = StudentFilterForm(request.GET)
    students = Student.objects.all()
    
    # Apply filters
    if filter_form.is_valid():
        search = filter_form.cleaned_data.get('search')
        grade = filter_form.cleaned_data.get('grade')
        sort_by = filter_form.cleaned_data.get('sort_by') or 'roll'
        order = filter_form.cleaned_data.get('order') or 'asc'
        
        if search:
            students = students.filter(
                Q(name__icontains=search) | Q(roll__icontains=search)
            )
        
        if grade:
            students = students.filter(grade=grade)
        
        # Apply sorting
        if order == 'desc':
            sort_by = f'-{sort_by}'
        students = students.order_by(sort_by)
    
    return render(request, 'student_list.html', {
        'students': students,
        'filter_form': filter_form
    })

def home(request):
    return render(request, 'home.html')


"""-----------------create object(table), reterive data, update, delete
ORM :
ORM (Object-Relational Mapping) is a programming technique used to manage the interaction between relational databases and object-oriented programming languages. It allows developers to interact with a database using objects, without writing raw SQL queries.

In the context of Django, ORM is a core feature that enables developers to work with databases in a Pythonic way. Instead of writing SQL, you define models in Python, and Django translates these models into database schema and queries.

How ORM Works in Django
Define Models:
Models in Django represent the database tables. Each model is a Python class that inherits from django.db.models.Model.

Steps to create table in models.py, insert data via form to database, connect models.py(table) to form, reterive data from database and display it in html on screen.

1. Define Models : creae table in models.py
2. Create Forms : create form in  HTML file and connect with views.py
3. Create Views : create views.py to connect models.py and forms.py
4. Create Templates : create HTML file to display data
5. Configure URLs : create urls.py to connect views.py and HTML file
6. Migrate Database : create database and table using migrate command : python manage.py makemigrations and python manage.py migrate
7. Run Server : run server using python manage.py runserver
8. Reterive data from databse and display it in HTML file using views.py and models.py.

"""