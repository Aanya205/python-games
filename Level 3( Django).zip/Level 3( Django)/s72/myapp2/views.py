from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse
# Create your views here.
def index(request):
    template = loader.get_template("index.html")
    name = {"student":"Aanya","age":"14"}
    return HttpResponse (template.render(name))
    
    # Steps to use the HTML file with manage.py
    # Step 1: Create an HTML file and do the HTML coding in that
    #Step 2: Import a loader function in the views.py like done on line 2 because its work is to load and store the HTML file in a variable
    #Step 3: On line number 5 we use a loader class and from there we use the get template function which is an inbuilt function which is used to store HTML file in a variable
    #Step 4: Use HttpResponse function to pass the variable in that and then use render (which is used to display the data on screen)
    #Step 5: The last step is to call this function in the url.py

    #Steps to create a variable:
    # Step 1: Create a varible in manage.py and then er join that variable with the tag in HTML file
    #Step 2 : Always use double {{}} whenever we combine a variable

    # one hw s71 and then s72 they both should be seperate