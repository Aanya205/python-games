from django.apps import AppConfig


class App75HwConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app75hw'
