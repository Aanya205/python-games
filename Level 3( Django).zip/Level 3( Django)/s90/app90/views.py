from django.shortcuts import render, redirect
from django.http import HttpResponse

tasks = []  # Here we create a list 'tasks' where all tasks will be stored, which we get from the input box.
            # Later, this list will be sent to the HTML file and displayed using the 'for' tag with <ul><li>.

def index(request):
    if request.method == "POST":
        task = request.POST.get('task')  # here we get task via get function
        if task:
            tasks.append(task)  # ✅ Add task to the list — FIXED here
        return redirect("/")

    return render(request, 'index.html', {'tasks': tasks})
    # This {'tasks': tasks} is done to send the task list to the HTML file 

def delete(request, task_id):
    if 0 <= task_id < len(tasks):
        tasks.pop(task_id)  # This removes the task at the given index
    return redirect("/")


    
