from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
# Create your views here.

def hello(request):
    t = loader.get_template("tags.html")
    return HttpResponse(t.render())
