from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader

def hello(request):
    t = loader.get_template("base.html")
    return HttpResponse(t.render())

def hello1(request):
    a = loader.get_template("logout.html")
    return HttpResponse(a.render())

def hello2(request):
    b = loader.get_template("login.html")
    return HttpResponse(b.render())

def hello3(request):
    c = loader.get_template("register.html")
    return HttpResponse(c.render())

def hello4(request):
    d = loader.get_template("profile.html")
    return HttpResponse(d.render())


#Remember always call all functions in url.py
#----------------------------------Steps to connect one html file with another using a tag-------------
#1. call all html files in different functions in views.py like we have done above.
#2.  First go to url.py and add call all functions whcih created in views.py by writing example : path("Home/", name=views.functionname, name="anymame")
#3. in html file in a tag write the name which given in url.py

# Create your views here.
