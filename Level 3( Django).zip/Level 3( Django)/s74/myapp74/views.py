from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.

def filters_function(request):
    student = {"name":"Aanya", "age":14}
    return HttpResponse(student)

