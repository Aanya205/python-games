from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.core.mail import send_mail, get_connection
from .forms import ContactForm  # Import your form

def contact_us(request):
    submitted = False  # Initialize the submitted flag
    if request.method == "POST":  # Corrected "post" to "POST"
        form = ContactForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data  # Get the cleaned data from the form
            con = get_connection('django.core.mail.backends.console.EmailBackend')  # Set up email connection
            # Send an email with the form data
            send_mail(
                cd["subject"],  # Email subject
                cd["message"],  # Email message
                cd.get("email", "no-reply@example.com"),  # Sender email
                ["siteowner@example.com"],  # Recipient email
                connection=con,
            )
            return HttpResponseRedirect('/contact?submitted=True')  # Redirect with a success flag
    else:
        form = ContactForm()  # Instantiate a blank form
        if 'submitted' in request.GET:
            submitted = True  # Check if the form was successfully submitted

    # Render the form and submission status
    return render(request, 'contact.html', {'form': form, 'submitted': submitted})
