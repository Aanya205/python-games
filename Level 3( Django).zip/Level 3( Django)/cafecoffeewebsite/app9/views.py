from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader

def hello(request):
    a = loader.get_template("home.html")
    return HttpResponse(a.render())



# Create your views here.

