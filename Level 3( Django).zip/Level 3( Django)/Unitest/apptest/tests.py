from django.test import TestCase
from.models import Books
#testing means testing each and every part of the code using the test case function
# if we test just 1 or 2 parts its called unit testing.
#if we test all the parts its called integration testing
#testing is important so that we dont face any issue later or to avoid any bugs
#in order to get smooth output
#We will be creating a model class for database with columns and then in the test.py we will test all the columns
#we will test wether those columns exist or not and also the data inside those columsn
# we always do this testing in test.py
#we do testing of models.py, forms.py, views.py 
# we dont do testing of html
#in the test.py we will be creating diff. functions for each column
#to test the yesting we run the command python manage.py test
# if the dots are coming in termianl that means the testing is succesfull. If fail comes that means the test has failed

# Create your tests here.
#one inbuilt function setUp() is there where we code to save details in columns as columns are empty.
#we put data in column of database which we created in models.py.  and after that we created 3 function for column for test
class BookModelTest(TestCase):
   def setUp(self):
    #we use modelname.objects.create()is used to insert data in database in dhango
    #we modelname.objects.all() to get data from database
    # we use modelname.objects.get(id) to get specific data from database. 
    # we use modelname.objects.update() to update data
    #we use modelname.objects.delete() to delete data
     Books.objects.create(title="hello", author="John", bookname="the universe")
   #these our own function so anyname can be given to them.
   #we create 3 function. 
   def test_title_field(self):
    #we check if column title in database has hello or not
    #first we get title from database tehn we use inbuilt funtion called as 
    #assertEqual taht check if title we get from database is equal to hello
     b=Books.objects.get(title='hello')
     self.assertEqual(b.title, 'hello')
  
   def test_author_field(self):
     b=Books.objects.get(author='John')
     self.assertEqual(b.author, 'John')


   def test_book_field(self):
     b=Books.objects.get(bookname = 'the universe')
     self.assertEqual(b.bookname,'the universe')

    

#Rememberwhen we do models code we always have to run command 
#python manage.py makemigrations n python manage.py migrate
# to convert models class to database so that database is created#tehn run 