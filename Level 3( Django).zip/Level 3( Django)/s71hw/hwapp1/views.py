from django.shortcuts import render
from django.http import HttpResponse



def function(request):
    text = """<h1>I am learning Django Course</h1>"""
    return HttpResponse(text)

#There is an error when i run it
#Dont forget to add the app name in settings.py under apps
# and dont forget to import everything into the url.py
