from django import forms
from .models import SimpleModel

class AuthForms(forms.ModelForm):
  # we create title, name, description
  class Meta:
    # call model
    model = SimpleModel
    fields = ['name', 'title', 'description']
    widgets = {
        'description': forms.Textarea(attrs={'rows': 3}),
    }
  