from django.shortcuts import render, redirect, get_object_or_404
from .forms import AuthForms
from .models import SimpleModel

#-------------------Crud Example-----------------------
def simple_form_view(request):
    if request.method == 'POST':
        form = AuthForms(request.POST) # call forms class here by creating the object
        if form.is_valid(): # check if details have been submitted to forms and then save it 
            form.save()# later display HTML page
            return render(request, 'forms.html')  # Redirect to a thank-you page or similar
    else:
        form = AuthForms()
    return render(request, 'forms1.html', {'form': form})

#------------------------ListView, CreateView, DetailView Example---------------------------

#In Django, a ListView is a class-based view provided by Django's django.views.generic module. It is used to display a list of objects from a database. ListView is particularly helpful when you want to quickly create views that render lists of items without writing much boilerplate code.


def list_view(request):
    simplemodels = SimpleModel.objects.all()
    return render(request, 'simplemodel_list.html', {'simplemodels': simplemodels})

# ---------------------Create view-------------------------
#Used to handle the creation of new objects. It provides a form that users can fill out to create a new record in the database.

#Key Features:
#Automatically generates a form based on a model.

#Handles both GET (form rendering) and POST (form submission) requests.

#Redirects to a success URL upon successful form submission.
def create_view(request):
    if request.method == 'POST':
        form = AuthForms(request.POST)
        if form.is_valid():
            form.save()
            return redirect('simplemodel_list')
    else:
        form = AuthForms()
    return render(request, 'simplemodel_create.html', {'form': form})

# ----------------------Detail view------------------------
#Used to display the details of a single object.

#Key Features:
#Automatically retrieves an object based on a primary key or slug.

#Renders a detail template with the object's data.

def detail_view(request, pk):
    simplemodel = get_object_or_404(SimpleModel, pk=pk)
    return render(request, 'simplemodel_detail.html', {'simplemodel': simplemodel})

# ----------------------Update view------------------------
#Used to handle the updating of existing objects. It provides a form pre-filled with the current data.

def update_view(request, pk):
    simplemodel = get_object_or_404(SimpleModel, pk=pk)
    if request.method == 'POST':
        form = AuthForms(request.POST, instance=simplemodel)
        if form.is_valid():
            form.save()
            return redirect('simplemodel_detail', pk=pk)
    else:
        form = AuthForms(instance=simplemodel)
    return render(request, 'simplemodel_update.html', {'form': form, 'simplemodel': simplemodel})

# ----------------------Delete view------------------------
#Used to handle the deletion of objects.

def delete_view(request, pk):
    simplemodel = get_object_or_404(SimpleModel, pk=pk)
    if request.method == 'POST':
        simplemodel.delete()
        return redirect('simplemodel_list')
    return render(request, 'simplemodel_delete.html', {'simplemodel': simplemodel})
