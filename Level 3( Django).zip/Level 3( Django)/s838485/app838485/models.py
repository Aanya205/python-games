#-----------------------------------Crud
#CRUD in Django involves implementing Create, Read, Update, and Delete operations(query) data in database. using Django's Models, Views, Forms, and Templates. it is same as we use to create table, update, delete, insert query in mysql and sqlite  in level 1. but here in djnago instead of using queries we use models.py, forms.py, views.py files and there functions. eventually we are updating data, deleteing data, inserting data in databse but with alternate way. 

#from django.db import models
#Steps to be folowed:
#1. in models.py create model class and inside fields(columns). 
#2. connect to forms.py  and there we create one form via which user enter details
#3. views.py we class form class using object. also check if form is valid or not. and also import our html file
#4. in html file we create button
#5. call function i url.py
from django.db import models

class SimpleModel(models.Model):
    name = models.CharField(max_length=100)
    title = models.CharField(max_length=200)
    description = models.TextField()

    def __str__(self):
        return self.title