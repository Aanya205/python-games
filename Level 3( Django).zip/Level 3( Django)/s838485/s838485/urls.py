"""
URL configuration for s838485 project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect
from app838485.views import simple_form_view, list_view, create_view, detail_view, update_view, delete_view

def root_redirect(request):
    return redirect('simple_form')

urlpatterns = [
    path('', root_redirect, name='root'),
    path('admin/', admin.site.urls),
    path('accounts/', include('allauth.urls')),
    path('simpleform/', simple_form_view, name='simple_form'),
    path('simplemodels/', list_view, name='simplemodel_list'),
    path('simplemodels/create/', create_view, name='simplemodel_create'),
    path('simplemodels/<int:pk>/', detail_view, name='simplemodel_detail'),
    path('simplemodels/<int:pk>/update/', update_view, name='simplemodel_update'),
    path('simplemodels/<int:pk>/delete/', delete_view, name='simplemodel_delete'),
]
