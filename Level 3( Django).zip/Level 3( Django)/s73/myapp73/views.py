from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse
               #Here we will be learning how to use conditions in HTML language:
# Usually we dont hv condition, loops or variables in HTML because HTML has only tags that we use but when we use HTML with django then we have an if and for tag which are special types of tags.

# Create your views here.

def hello(request):
# we are going to create a variable which we are going to get into the HTML file and we know 
# there is no varbale tag.
    template = loader.get_template("index.html")
    student = {"name":"Aanya","count":10, "list" : [["1", "2"], ["3","4"], ["5","6"]]} 
    return HttpResponse(template.render(student))

#HW
#Conditions:
# In django you can write a condition tag like this:
# {% if %} , {% endif %} , {% for %} , {% elif %}
# You write conditions in index.html

# The {% empty %} tag allows us to define the output if we want to.
#So it doesnt set a specific answer it allows us to decide

#Example of condition coding:
#{% block content %}
 #<h1> Welcome to Django </h1>
 #{% if student %}
 #<h2> My name is : {{The variable}}</h2>
#{% enblock content %}