from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse

def function(request):
    template = loader.get_template("index.html")
    bio = {"name" : "Steve Jobs", "age" :"56", "job":"Created apple"}
    return HttpResponse (template.render(bio))
    

# add name into settings.py and do url
