from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from.forms import student_form
def hello(request):
    student = student_form()
    #created the object of the class on line 6 in forms.py

    return render(request,"student.html", {"form":student})
    #Here in line 8 we have passed the html passed along with the object of the form in order to display on screen. Render is the one that is displaying on the screen.
    #So we have to pass both: the file which has button and the form which has 2 boxes
# Create your views here.
