#There are two ways to create a form. Form means something where we take in details from the user.
#1) we can do html coding by using the different tags like form tag and input tag etc.
#2)we can create pythong file like forms.py and inside that we can use some python funciton like:
# BooleanFeild , CharFeild , ChoiceFeild, DateFeild , DateTimeFeild , DecimalFeild , EmailFeild , FileFeild , ImageFeild
#These are the functions we can use to create a form
#All theae different types of boxes or drop downs but if we want to create a button we will have to go to html file
#Steps to create a form in python:
#1)Create a class in forms.py
#2)Then inside the class you can use diff. type of functions
#3)Then import forms.py in the views.py
#4)then call function in the url.py
from django import forms
class student_form(forms.Form):
    username = forms.CharField(label = "Enter your username", max_length = 50)
    password = forms.CharField(label = "Enter your password", max_length = 50)